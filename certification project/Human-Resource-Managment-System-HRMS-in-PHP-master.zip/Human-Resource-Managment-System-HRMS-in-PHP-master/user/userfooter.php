<!-- ASIDE NAV 2 -->
              <!-- <aside class="s-12 l-3">
                  <h3>Navi</h3>
                  <div class="aside-nav">
                     <ul>
                        <li><a>Home</a></li>
                        <li>
                           <a>Product</a>
                           <ul>
                              <li><a>Product 1</a></li>
                              <li><a>Product 2</a></li>
                              <li>
                                 <a>Product 3</a>
                                 <ul>
                                    <li><a>Product 3-1</a></li>
                                    <li><a>Product 3-2</a></li>
                                    <li><a>Product 3-3</a></li>
                                 </ul>
                              </li>
                           </ul>
                        </li>
                        <li>
                           <a>Company</a>
                           <ul>
                              <li><a>About</a></li>
                              <li><a>Location</a></li>
                           </ul>
                        </li>
                        <li><a>Contact</a></li>
                     </ul>
                  </div>
               </aside> 
            </div>
         </div>
      </div>
      <!-- FOOTER -->
      <footer class="box" style="position: fixed; bottom: 0;">
         <div class="line">
            <div class="s-12 l-12">
              
            </div>
         </div>
      </footer>
      <script type="text/javascript" src="js/responsee.js"></script>
   </body>
</html>