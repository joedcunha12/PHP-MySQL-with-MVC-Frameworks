# Human-Resource-Managment-System-HRMS-in-PHP
Human resource managment system is simple mini project built  using PHP
![mainpage](https://user-images.githubusercontent.com/4586123/57188638-a423f500-6f1f-11e9-82cb-4d435d8a0dfb.JPG)
</br>
The aim of this Human Resource Management System project is to build a system that will help a company
manage its human resources. The Human Resource Management System will have a project module. All
records of employees will be maintained on the system along with their skills and abilities. When a new project
is assigned to a team the project module creates a new file. The details of the team members and estimated
project completion time will be noted. The project supervisor will be required to update evaluations of team
members on the system. These evaluations will be used by the system to make recommendations for promotions
and raises. The final decision on promotions and raises will be made by an upper level manager.
</br>

A recruitment module can be used during the hiring process. This module will have access to information
about future projects and progress on currents projects, based on this information it will predict requirement of
talent.
</br>
</br>
An employee module will be available to all employees to view their payroll and sanctioned leaves. All
employees can easily verify the information and raise queries with the Human Resource Management System at
any time using this system. Higher level management will be able to access employee records and job statistics
using this system.
